#! /usr/bin/env perl

require 5.001;
use strict;
use warnings;
use File::Copy;
use Getopt::Tabular;
use File::Basename;
use FindBin;

my $Usage   =   <<USAGE;

This pipeline takes the MNI space ROIs, multiply them with NIAK's GM masks in MNI space and resample the output into asl space using the xfm created by NIAK.

Usage $0 [options]

-help for options

USAGE

my $log_dir     ='/home/cmadjar/database/PreventAD/cecile/scripts/native2func_resample/logs';
my $gm_masks_dir;
my $niak_dir;
my $templateROI_dir;
my $roi_basename;
my $roi_masks_dir;
my ($asl_list, @args);

my @args_table = (["-asl_list",         "string", 1, \$asl_list,        "list of ASL files in NIAK's fmri folder"       ],
		          ["-log_dir",          "string", 1, \$log_dir,         "directory for log files"                       ],
		          ["-niak_dir",         "string", 1, \$niak_dir,        "NIAK outputs directory"                        ],
		          ["-gm_masks_dir",     "string", 1, \$gm_masks_dir,    "Transformed grey matter masks' directory"      ],
		          ["-roi_masks_dir",    "string", 1, \$roi_masks_dir,   "Transformed ROI masks' directory"              ],
		          ["-roi_name",         "string", 1, \$roi_basename,    "ROI basename to use to create subject's mask"  ],
		          ["-templateROIs_dir", "string", 1, \$templateROI_dir, "Template ROIs (ROIs to transform) directory"   ]
		         );

Getopt::Tabular::SetHelp ($Usage,'');
GetOptions(\@args_table,\ @ARGV,\@args) || exit 1;

# needed for log file
my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);
my $date    = sprintf("%4d-%02d-%02d_%02d:%02d:%02d",$year+1900,$mon+1,$mday,$hour,$min,$sec);
my $log     = "$log_dir/ROI_in_ASL_space_$date.log";
open(LOG,">>$log");
print LOG "Log file, $date\n\n";

if(!$asl_list)          { print "You need to specify a file with the list of directory to analyze.\n";          exit 1; }
if(!$gm_masks_dir)      { print "You need to specify a directory where grey mater masks will be created.\n";    exit 1; }
if(!$roi_masks_dir)     { print "You need to specify a directory where ROI masks will be created.\n";           exit 1; }
if(!$niak_dir)          { print "You need to specify a directory with NIAK results.\n";                         exit 1; }
if(!$roi_basename)      { print "You need to specify a basename to use to create mask in subject's space.\n";   exit 1; }
if(!$templateROI_dir)   { print "You need to specify a directory with the ROI template (in MNI space).\n";      exit 1; }

open(ASLS,"<$asl_list");
my @asls    = <ASLS>;
close(ASLS);
foreach my $asl (@asls) {
    chomp($asl);

    ### Get site, candID, visit label and niakID from asl file name ($asl)
    my ($site, $candID, $visit, $asl_run, $niakID) = getSiteSubjectVisitIDs($asl);
    next    if ((!$site) || (!$candID) || (!$visit) || (!$asl_run) || (!$niakID));
#    print LOG   "Site \t\tCandID \t\tVisit \t\tASL run\n$site \t$candID \t\t$visit \t$asl_run\n";
    print       "Site \t\tCandID \t\tVisit \t\tASL run\n$site \t$candID \t\t$visit \t$asl_run\n";

    ### Get GM mask in NIAK's outputs (in anat folder)
    my $mask_pattern    = "^anat_$niakID\_pve_gm_stereolin.mnc\$";
    my ($gm_file)       = getFile($niak_dir, $mask_pattern, $niakID);
    if (!$gm_file) {
#        print LOG   "Could not find a mask to transform for $site $candID $visit.\n";
        print       "Could not find a mask to transform for $site $candID $visit.\n";
        next;
    }
#    print LOG   "Mask to transform is: $gm_file \n";
    print       "Mask to transform is: $gm_file \n";

    ### Get ROI mask in template mask directory
    my ($roi_file)      = getFile($templateROI_dir, $roi_basename);

    ### Fetches XFM transform from native asl (func) space to stereotaxic space (in NIAK anat folder)
    my ($xfm_pattern)           = "^transf_$niakID\_nativefunc_to_stereolin.xfm\$";
    my ($func2stereolin_xfm)    = getFile($niak_dir, $xfm_pattern, $niakID);
    if (!$func2stereolin_xfm) {
#        print LOG   "Could not find nativefunc_to_stereolin XFM for $site $candID $visit.\n";    
        print       "Could not find nativefunc_to_stereolin XFM for $site $candID $visit.\n";    
        next;
    }
#    print LOG   "Nativefunc_to_stereolin XFM file is: $func2stereolin_xfm \n";
    print       "Nativefunc_to_stereolin XFM file is: $func2stereolin_xfm \n";

    ### Create GM and ROI output directories 
    my ($gm_out_dir)   = createOutDirectories($gm_masks_dir, $candID, $visit);
    my ($roi_out_dir)  = createOutDirectories($roi_masks_dir, $candID, $visit);
#    print LOG   "GM out dir:   $gm_out_dir  \n";
    print       "GM out dir:   $gm_out_dir  \n";
#    print LOG   "ROI out dir:  $roi_out_dir \n";
    print       "GM out dir:   $gm_out_dir  \n";

    ### Determine name of the transformed masks
    my ($gm_transformed_mask)   = getOutputMaskName($asl_run, $gm_out_dir,  $candID, $visit, $site, "niak_pve_gm_stereolin");
    my ($roi_transformed_mask)  = getOutputMaskName($asl_run, $roi_out_dir, $candID, $visit, $site, $roi_basename);
#    print LOG   "GM out file:  $gm_transformed_mask   \n";
    print       "GM out file:  $gm_transformed_mask   \n";
#    print LOG   "ROI out file: $roi_transformed_mask  \n";
    print       "ROI out file: $roi_transformed_mask  \n";

    ### Resample mask to asl space using mincresample and above informations
    resample_mask2asl($niak_dir, $asl, $gm_masks_dir,  $gm_file,  $gm_transformed_mask,  $func2stereolin_xfm);
    resample_mask2asl($niak_dir, $asl, $roi_masks_dir, $roi_file, $roi_transformed_mask, $func2stereolin_xfm);
    
    my ($roi_gm_transformed_mask)   = getOutputMaskName($asl_run, $roi_out_dir, $candID, $visit, $site, "$roi_basename\_gm");
    multiplyROIandGMmasks($gm_transformed_mask, $roi_transformed_mask, $roi_gm_transformed_mask);
}


###############
## Functions ##
###############

=pod
Fetches from asl scan references (Site, CandID, Visit, Scan number) and returns them.
=cut
sub getSiteSubjectVisitIDs {
    my ($asl)   = @_;

    if ($asl =~ m/^fmri_s(\d+)v([N,P][A,R][P,E][B,F][L,U]\d+)_[a-z0-9]+_(asl\d+).mnc$/i){
        my $site    ="PreventAD";
        my $candID  =$1;
        my $visit   =$2;
        my $asl_run =$3;
        my $niakID  = "s" . $candID . "v" . $visit;
        return($site,$candID,$visit,$asl_run,$niakID);
    }else{
        return undef;
    }
}

=pod
Fetches in masks directory every GM masks in native space for Site, CandID, Visit and return them into a hash %mask with mask_run number in key and mask in value (e.g. $masks{001} = PreventAD_966786_NAPBL00_adniT1_001_pve_gm_native.mnc).
=cut
sub getFile {
    my ($dir, $pattern, $niakID) = @_;

    my ($file_dir, $file);
    if ($niakID) { $file_dir = $niak_dir . "/anat/" . $niakID . "/";}
    else         { $file_dir = $dir . "/";}

    opendir(DIR, $file_dir);
    my @entries = readdir(DIR);
    closedir(DIR);

    my ($entry) = grep(/$pattern/i, @entries);
    
    if ($niakID) { $file = $niak_dir . "/anat/" . $niakID . "/" . $entry;}
    else         { $file = $dir . "/" . $entry;}
    $file       =~ s/\/\//\//;  # get rid of //

    return ($file);
}

=pod
Create output directories based on CandID and visit.
=cut
sub createOutDirectories {    
    my ($masks_dir, $candID, $visit) = @_;

    my $cand_dir    =   "$masks_dir/$candID";
    $cand_dir       =~  s/\/\//\//;  # get rid of //
    mkdir "$cand_dir"          unless (-e "$cand_dir");
    mkdir "$cand_dir/$visit"   unless (-e "$cand_dir/$visit");

    return ("$cand_dir/$visit");
}

=pod
Determine mask output name based on output mask directory, candID, visit, site, asl run number and mask basename to use.
=cut
sub getOutputMaskName {
    my ($asl_run, $masks_dir, $candID, $visit, $site, $mask_basename) = @_;

    my $end_file        = $asl_run . "res.mnc";
    $end_file           =~ s/asl/ASL00/; # replace asl by ASL00 to get ASL001 ASL002 etc..
    my $transformed_mask= $masks_dir . "/" . $site . "_" . $candID . "_" . $visit . "_" . $mask_basename . "_" . $end_file;
    $transformed_mask   =~ s/\/\//\//;  # get rid of //

    return ($transformed_mask);
}

=pod
Resample masks to ASL space.
=cut
sub resample_mask2asl {
    my ($niak_dir, $asl, $masks_dir, $mask_file, $transformed_mask, $func2stereolin_xfm)   = @_;

    my $like    = "$niak_dir/fmri/$asl";
    $like       =~ s/\/\//\//;  # get rid of //
    my $command = "mincresample "                           .
                    "-transformation $func2stereolin_xfm "  .
                    "-invert_transformation "               . 
                    "-like $like "                          .
                    "-nofill "                              .
                    "-trilinear "                           .
                    "$mask_file "                           .
                    $transformed_mask                       ;

    print "Executing: " . $command . "\n\n";
    system($command) unless (-e $transformed_mask);
}

sub multiplyROIandGMmasks { 
    my ($gm_transformed_mask, $roi_transformed_mask, $roi_gm_transformed_mask)    = @_;

    my $command = "mincmath "                                           .
                    "-mul $gm_transformed_mask $roi_transformed_mask "  .
                    "$roi_gm_transformed_mask "                         ;

    my $resampling  = "mincresample "                           .
                        "-clobber "                             .
                        "-like $gm_transformed_mask "           .
                        "-nofill "                              .
                        "-trilinear "                           .
                        "$roi_gm_transformed_mask "             .
                        $roi_gm_transformed_mask                ;

    unless (-e $roi_gm_transformed_mask) {
        print "Executing: $command \n\n";
        system($command);
        print "Executing: $resampling \n\n";
        system($resampling);
    }
}    
