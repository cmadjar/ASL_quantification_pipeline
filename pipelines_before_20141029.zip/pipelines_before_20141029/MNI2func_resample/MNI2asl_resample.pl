#! /usr/bin/env perl

require 5.001;
use strict;
use warnings;
use File::Copy;
use Getopt::Tabular;
use File::Basename;
use FindBin;

my $Usage   =   <<USAGE;

This pipeline takes GM masks in native T1 space and resample them into asl space using xfm created by NIAK.

Usage $0 [options]

-help for options

USAGE

my $log_dir     ='/home/cmadjar/database/PreventAD/cecile/scripts/native2func_resample/logs';
my $masks_dir;
my $niak_dir;
my ($asl_list, @args);

my @args_table = (["-asl_list", "string", 1, \$asl_list, "list of ASL files in NIAK's fmri folder"],
		          ["-log_dir",  "string", 1, \$log_dir,  "directory for log files"                ],
		          ["-masks_dir","string", 1, \$masks_dir,"GM masks' directory"                    ],
		          ["-niak_dir", "string", 1, \$niak_dir, "NIAK outputs directory"                 ]
		         );

Getopt::Tabular::SetHelp ($Usage,'');
GetOptions(\@args_table,\ @ARGV,\@args) || exit 1;

# needed for log file
my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);
my $date    = sprintf("%4d-%02d-%02d_%02d:%02d:%02d",$year+1900,$mon+1,$mday,$hour,$min,$sec);
my $log     = "$log_dir/GM_in_ASL_space_$date.log";
open(LOG,">>$log");
print LOG "Log file, $date\n\n";

if(!$asl_list) { print "You need to specify a file with the list of directory to analyze.\n"; exit 1;}
if(!$masks_dir){ print "You need to specify a directory where masks will be created.\n"; exit 1;}
if(!$niak_dir) { print "You need to specify a directory with NIAK results.\n"; exit 1;}

open(ASLS,"<$asl_list");
my @asls    = <ASLS>;
close(ASLS);
foreach my $asl (@asls) {
    chomp($asl);

    # Get site, candID, visit label and niakID from asl file name ($asl)
    my ($site, $candID, $visit, $asl_run, $niakID) = getSiteSubjectVisitIDs($asl);
    next    if ((!$site) || (!$candID) || (!$visit) || (!$asl_run) || (!$niakID));
    print LOG   "Site \t\tCandID \t\tVisit \t\tASL run\n$site \t$candID \t\t$visit \t$asl_run\n";
    print       "Site \t\tCandID \t\tVisit \t\tASL run\n$site \t$candID \t\t$visit \t$asl_run\n";

    # Get GM mask in NIAK's outputs (in anat folder)
    my $mask_pattern    = "^anat_$niakID\_pve_gm_stereolin.mnc\$";
    my ($mask_file)        = getNiakFile($niak_dir, $niakID, $mask_pattern);
    if (!$mask_file) {
        print LOG   "Could not find a mask to transform for $site $candID $visit.\n";
        next;
    }
    print LOG   "Mask to transform is: $mask_file \n";
    print       "Mask to transform is: $mask_file \n";

    ### Fetches XFM transform from native asl (func) space to stereotaxic space (in NIAK anat folder)
    my ($xfm_pattern)           = "^transf_$niakID\_nativefunc_to_stereolin.xfm\$";
    my ($func2stereolin_xfm)   = getNiakFile($niak_dir, $niakID, $xfm_pattern);
    if (!$func2stereolin_xfm) {
        print LOG   "Could not find nativefunc_to_stereolin XFM for $site $candID $visit.\n";    
        next;
    }
    print LOG   "Nativefunc_to_stereolin XFM file is: $func2stereolin_xfm \n";
    print       "Nativefunc_to_stereolin XFM file is: $func2stereolin_xfm \n";

    ### Create output directories in $masks_dir ($masks_dir/$candID/$visit)
    my $cand_dir    =   "$masks_dir/$candID";
    $cand_dir       =~  s/\/\//\//;  # get rid of //
    mkdir "$cand_dir"          unless (-e "$cand_dir");
    mkdir "$cand_dir/$visit"   unless (-e "$cand_dir/$visit");

    ### Resample mask to asl space using mincresample and above informations
    my $end_file        = $asl_run . "res.mnc";
    $end_file           =~ s/asl/ASL00/; # replace asl by ASL00 to get ASL001 ASL002 etc..
    my $transformed_mask= $masks_dir . "/" . $candID . "/" . $visit . "/" . 
                            $site . "_" . $candID . "_" . $visit . "_niak_pve_gm_stereolin_" . $end_file;
    $transformed_mask   =~ s/\/\//\//;  # get rid of //
    resample_mask2asl($niak_dir, $asl, $masks_dir, $mask_file, $transformed_mask, $func2stereolin_xfm);

}


###############
## Functions ##
###############

=pod
Fetches from asl scan references (Site, CandID, Visit, Scan number) and returns them.
=cut
sub getSiteSubjectVisitIDs {
    my ($asl)   = @_;

    if ($asl =~ m/^fmri_s(\d+)v([N,P][A,R][P,E][B,F][L,U]\d+)_[a-z0-9]+_(asl\d+).mnc$/i){
        my $site    ="PreventAD";
        my $candID  =$1;
        my $visit   =$2;
        my $asl_run =$3;
        my $niakID  = "s" . $candID . "v" . $visit;
        return($site,$candID,$visit,$asl_run,$niakID);
    }else{
        return undef;
    }
}

=pod
Fetches in masks directory every GM masks in native space for Site, CandID, Visit and return them into a hash %mask with mask_run number in key and mask in value (e.g. $masks{001} = PreventAD_966786_NAPBL00_adniT1_001_pve_gm_native.mnc).
=cut
sub getNiakFile {
    my ($niak_dir, $niakID, $pattern) = @_;

    opendir(DIR, "$niak_dir/anat/$niakID/");
    my @entries = readdir(DIR);
    closedir(DIR);

    my ($entry) = grep(/$pattern/i, @entries);
    my $file    = $niak_dir . "/anat/" . $niakID . "/" . $entry;
    $file       =~ s/\/\//\//;  # get rid of //

    return ($file);
}

=pod
Resample masks to ASL space.
=cut
sub resample_mask2asl {
    my ($niak_dir, $asl, $masks_dir, $mask_file, $transformed_mask, $func2stereolin_xfm)   = @_;

    my $like    = "$niak_dir/fmri/$asl";
    $like       =~ s/\/\//\//;  # get rid of //
    my $command = "mincresample "                           .
                    "-transformation $func2stereolin_xfm "  .
                    "-invert_transformation "               . 
                    "-like $like "                          .
                    "-nofill "                              .
                    "-trilinear "                           .
                    "$mask_file "                           .
                    $transformed_mask                       ;

    print "Executing: " . $command . "\n\n";
    system($command) unless (-e $transformed_mask);
}
