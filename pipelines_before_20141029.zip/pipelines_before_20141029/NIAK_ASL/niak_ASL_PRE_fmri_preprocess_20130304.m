% Template to write a script for the NIAK fMRI preprocessing pipeline
%
% To run a demo of the preprocessing, please see
% NIAK_DEMO_FMRI_PREPROCESS.
%
% Copyright (c) Pierre Bellec, 
%   Montreal Neurological Institute, McGill University, 2008-2010.
%   Research Centre of the Montreal Geriatric Institute
%   & Department of Computer Science and Operations Research
%   University of Montreal, Québec, Canada, 2010-2012
% Maintainer : pierre.bellec@criugm.qc.ca
% See licensing information in the code.
% Keywords : medical imaging, fMRI, preprocessing, pipeline

% Permission is hereby granted, free of charge, to any person obtaining a copy
% of this software and associated documentation files (the "Software"), to deal
% in the Software without restriction, including without limitation the rights
% to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
% copies of the Software, and to permit persons to whom the Software is
% furnished to do so, subject to the following conditions:
%
% The above copyright notice and this permission notice shall be included in
% all copies or substantial portions of the Software.
%
% THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
% IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
% FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
% AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
% LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
% OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
% THE SOFTWARE.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Setting input/output files %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% WARNING: Do not use underscores '_' in the IDs of subject, sessions or runs. This may cause bugs in subsequent pipelines.


 %% Subject /data/preventAD/data/NIAK/ASL_DATA/195980 
files_in.s195980.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/195980/PREBL00/PreventAD_195980_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s195980.fmri.PREBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/195980/PREBL00/PreventAD_195980_PREBL00_ASL001.mnc';   % ASL run 1 


 %% Subject /data/preventAD/data/NIAK/ASL_DATA/632280 
files_in.s632280.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/632280/PREBL00/PreventAD_632280_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s632280.fmri.PREBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/632280/PREBL00/PreventAD_632280_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/352959 
files_in.s352959.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/352959/PREBL00/PreventAD_352959_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s352959.fmri.PREBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/352959/PREBL00/PreventAD_352959_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/585070 
files_in.s585070.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/585070/PREBL00/PreventAD_585070_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s585070.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/585070/PREBL00/PreventAD_585070_PREBL00_adniT1002.mnc';   %Structural scan 
files_in.s585070.fmri.PREBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/585070/PREBL00/PreventAD_585070_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/787460 
files_in.s787460.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/787460/PREBL00/PreventAD_787460_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s787460.fmri.PREBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/787460/PREBL00/PreventAD_787460_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/229327 
files_in.s229327.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/229327/PREBL00/PreventAD_229327_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s229327.fmri.PREBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/229327/PREBL00/PreventAD_229327_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/917380 
files_in.s917380.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/917380/PREBL00/PreventAD_917380_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s917380.fmri.PREBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/917380/PREBL00/PreventAD_917380_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/182051 
files_in.s182051.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/182051/PREBL00/PreventAD_182051_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s182051.fmri.PREBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/182051/PREBL00/PreventAD_182051_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/456836 
files_in.s456836.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/456836/PREBL00/PreventAD_456836_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s456836.fmri.PREBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/456836/PREBL00/PreventAD_456836_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/713086 
files_in.s713086.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/713086/PREBL00/PreventAD_713086_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s713086.fmri.PREBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/713086/PREBL00/PreventAD_713086_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/981116 
files_in.s981116.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/981116/PREBL00/PreventAD_981116_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s981116.fmri.PREBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/981116/PREBL00/PreventAD_981116_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/650513 
files_in.s650513.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/650513/PREBL00/PreventAD_650513_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s650513.fmri.PREBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/650513/PREBL00/PreventAD_650513_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/706998 
files_in.s706998.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/706998/PREBL00/PreventAD_706998_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s706998.fmri.PREBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/706998/PREBL00/PreventAD_706998_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/122650 
files_in.s122650.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/122650/PREBL00/PreventAD_122650_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s122650.fmri.PREBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/122650/PREBL00/PreventAD_122650_PREBL00_ASL001.mnc';   % ASL run 1 


 %% Subject /data/preventAD/data/NIAK/ASL_DATA/211391 
files_in.s211391.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/211391/PREBL00/PreventAD_211391_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s211391.fmri.PREBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/211391/PREBL00/PreventAD_211391_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/196834 
files_in.s196834.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/196834/PREBL00/PreventAD_196834_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s196834.fmri.PREBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/196834/PREBL00/PreventAD_196834_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/508668 
files_in.s508668.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/508668/PREBL00/PreventAD_508668_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s508668.fmri.PREBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/508668/PREBL00/PreventAD_508668_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/600099 
files_in.s600099.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/600099/PREBL00/PreventAD_600099_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s600099.fmri.PREBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/600099/PREBL00/PreventAD_600099_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/259072 
files_in.s259072.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/259072/PREBL00/PreventAD_259072_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s259072.fmri.PREBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/259072/PREBL00/PreventAD_259072_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/703846 
files_in.s703846.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/703846/PREBL00/PreventAD_703846_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s703846.fmri.PREBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/703846/PREBL00/PreventAD_703846_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/668381 
files_in.s668381.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/668381/PREBL00/PreventAD_668381_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s668381.fmri.PREBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/668381/PREBL00/PreventAD_668381_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/864416 
files_in.s864416.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/864416/PREBL00/PreventAD_864416_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s864416.fmri.PREBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/864416/PREBL00/PreventAD_864416_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/910420 
files_in.s910420.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/910420/PREBL00/PreventAD_910420_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s910420.fmri.PREBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/910420/PREBL00/PreventAD_910420_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/757121 
files_in.s757121.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/757121/PREBL00/PreventAD_757121_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s757121.fmri.PREBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/757121/PREBL00/PreventAD_757121_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/726225 
files_in.s726225.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/726225/PREBL00/PreventAD_726225_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s726225.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/726225/PREBL00/PreventAD_726225_PREBL00_adniT1002.mnc';   %Structural scan 
files_in.s726225.fmri.PREBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/726225/PREBL00/PreventAD_726225_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/313754 
files_in.s313754.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/313754/PREBL00/PreventAD_313754_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s313754.fmri.PREBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/313754/PREBL00/PreventAD_313754_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/376416 
files_in.s376416.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/376416/PREBL00/PreventAD_376416_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s376416.fmri.PREBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/376416/PREBL00/PreventAD_376416_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/159332 
files_in.s159332.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/159332/PREBL00/PreventAD_159332_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s159332.fmri.PREBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/159332/PREBL00/PreventAD_159332_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/510111 
files_in.s510111.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/510111/PREBL00/PreventAD_510111_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s510111.fmri.PREBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/510111/PREBL00/PreventAD_510111_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/743428 
files_in.s743428.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/743428/PREBL00/PreventAD_743428_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s743428.fmri.PREBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/743428/PREBL00/PreventAD_743428_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/339400 
files_in.s339400.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/339400/PREBL00/PreventAD_339400_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s339400.fmri.PREBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/339400/PREBL00/PreventAD_339400_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/855307 
files_in.s855307.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/855307/PREBL00/PreventAD_855307_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s855307.fmri.PREBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/855307/PREBL00/PreventAD_855307_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/925267 
files_in.s925267.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/925267/PREBL00/PreventAD_925267_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s925267.fmri.PREBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/925267/PREBL00/PreventAD_925267_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/336950 
files_in.s336950.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/336950/PREBL00/PreventAD_336950_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s336950.fmri.PREBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/336950/PREBL00/PreventAD_336950_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/463140 
files_in.s463140.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/463140/PREBL00/PreventAD_463140_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s463140.fmri.PREBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/463140/PREBL00/PreventAD_463140_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/832208 
files_in.s832208.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/832208/PREBL00/PreventAD_832208_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s832208.fmri.PREBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/832208/PREBL00/PreventAD_832208_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/295195 
files_in.s295195.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/295195/PREBL00/PreventAD_295195_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s295195.fmri.PREBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/295195/PREBL00/PreventAD_295195_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/827752 %%% Need to reinsert data in DB with right visit label !!!
%files_in.s827752.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/827752/PREBL01/PreventAD_827752_PREBL01_adniT1001.mnc';   %Structural scan 
%files_in.s827752.fmri.PREBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/827752/PREBL01/PreventAD_827752_PREBL01_ASL001.mnc';   % ASL run 1 



%%%%%%%%%%%%%%%%%%%%%%%
%% Pipeline options  %%
%%%%%%%%%%%%%%%%%%%%%%%

% General
opt.folder_out  = '/sb/project/gsf-624-aa/database/PreventAD/cecile/ASL_out/PRE/';    % Where to store the results
opt.size_output = 'quality_control';                             % The amount of outputs that are generated by the pipeline. 'all' will keep intermediate outputs, 'quality_control' will only keep the quality control outputs. 

% Slice timing correction (niak_brick_slice_timing)
opt.slice_timing.type_acquisition = 'sequential descending'; % Slice timing order (available options : 'sequential ascending', 'sequential descending', 'interleaved ascending', 'interleaved descending')
opt.slice_timing.type_scanner     = 'Siemens';                % Scanner manufacturer. Only the value 'Siemens' will actually have an impact
opt.slice_timing.delay_in_tr      = 0.05;                       % The delay in TR ("blank" time between two volumes)
opt.slice_timing.suppress_vol     = 0;                       % Number of dummy scans to suppress.
opt.slice_timing.flag_skip        = 1;                       % Skip the slice timing (0: don't skip, 1 : skip)

% Motion estimation (niak_pipeline_motion)
opt.motion.session_ref  = 'PREBL00'; % The session that is used as a reference. In general, use the session including the acqusition of the T1 scan.

% resampling in stereotaxic space
opt.resample_vol.interpolation = 'trilinear'; % The resampling scheme. The most accurate is 'sinc' but it is awfully slow
opt.resample_vol.voxel_size    = [3 3 3];     % The voxel size to use in the stereotaxic space
opt.resample_vol.flag_skip     = 1;           % Skip resampling (data will stay in native functional space after slice timing/motion correction) (0: don't skip, 1 : skip)

% Linear and non-linear fit of the anatomical image in the stereotaxic
% space (niak_brick_t1_preprocess)
opt.t1_preprocess.nu_correct.arg = '-distance 50'; % Parameter for non-uniformity correction. 200 is a suggested value for 1.5T images, 50 for 3T images. If you find that this stage did not work well, this parameter is usually critical to improve the results.

% T1-T2 coregistration (niak_brick_anat2func)
opt.anat2func.init = 'identity'; % An initial guess of the transform. Possible values 'identity', 'center'. 'identity' is self-explanatory. The 'center' option usually does more harm than good. Use it only if you have very big misrealignement between the two images (say, 2 cm).

% Temporal filtering (niak_brick_time_filter)
opt.time_filter.hp = 0.01; % Cut-off frequency for high-pass filtering, or removal of low frequencies (in Hz). A cut-off of -Inf will result in no high-pass filtering.
opt.time_filter.lp = Inf;  % Cut-off frequency for low-pass filtering, or removal of high frequencies (in Hz). A cut-off of Inf will result in no low-pass filtering.

% Regression of confounds and scrubbing (niak_brick_regress_confounds)
opt.regress_confounds.flag_wm = false;            % Turn on/off the regression of the average white matter signal (true: apply / false : don't apply)
opt.regress_confounds.flag_vent = false;          % Turn on/off the regression of the average of the ventricles (true: apply / false : don't apply)
opt.regress_confounds.flag_motion_params = false; % Turn on/off the regression of the motion parameters (true: apply / false : don't apply)
opt.regress_confounds.flag_gsc = false;          % Turn on/off the regression of the PCA-based estimation of the global signal (true: apply / false : don't apply)
opt.regress_confounds.flag_scrubbing = true;     % Turn on/off the scrubbing of time frames with excessive motion (true: apply / false : don't apply)
opt.regress_confounds.thre_fd = 0.5;             % The threshold on frame displacement that is used to determine frames with excessive motion in the scrubbing procedure

% Correction of physiological noise (niak_pipeline_corsica)
opt.corsica.sica.nb_comp             = 60;    % Number of components estimated during the ICA. 20 is a minimal number, 60 was used in the validation of CORSICA.
opt.corsica.threshold                = 0.15;  % This threshold has been calibrated on a validation database as providing good sensitivity with excellent specificity.
opt.corsica.flag_skip                = 1;     % Skip CORSICA (0: don't skip, 1 : skip). Even if it is skipped, ICA results will be generated for quality-control purposes. The method is not currently considered to be stable enough for production unless it is manually supervised.

% Spatial smoothing (niak_brick_smooth_vol)
opt.smooth_vol.fwhm      = 6;  % Full-width at maximum (FWHM) of the Gaussian blurring kernel, in mm.
opt.smooth_vol.flag_skip = 1;  % Skip spatial smoothing (0: don't skip, 1 : skip)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Run the fmri_preprocess pipeline  %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[pipeline,opt] = niak_pipeline_fmri_preprocess(files_in,opt);
