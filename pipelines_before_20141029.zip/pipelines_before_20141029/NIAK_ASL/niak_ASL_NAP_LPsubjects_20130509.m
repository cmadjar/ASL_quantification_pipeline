% Template to write a script for the NIAK fMRI preprocessing pipeline
%
% To run a demo of the preprocessing, please see
% NIAK_DEMO_FMRI_PREPROCESS.
%
% Copyright (c) Pierre Bellec, 
%   Montreal Neurological Institute, McGill University, 2008-2010.
%   Research Centre of the Montreal Geriatric Institute
%   & Department of Computer Science and Operations Research
%   University of Montreal, Québec, Canada, 2010-2012
% Maintainer : pierre.bellec@criugm.qc.ca
% See licensing information in the code.
% Keywords : medical imaging, fMRI, preprocessing, pipeline

% Permission is hereby granted, free of charge, to any person obtaining a copy
% of this software and associated documentation files (the "Software"), to deal
% in the Software without restriction, including without limitation the rights
% to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
% copies of the Software, and to permit persons to whom the Software is
% furnished to do so, subject to the following conditions:
%
% The above copyright notice and this permission notice shall be included in
% all copies or substantial portions of the Software.
%
% THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
% IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
% FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
% AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
% LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
% OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
% THE SOFTWARE.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Setting input/output files %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% WARNING: Do not use underscores '_' in the IDs of subject, sessions or runs. This may cause bugs in subsequent pipelines.


 %% Subject 1 /data/preventAD/data/NIAK/ASL_DATA/999145 
files_in.s999145.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/999145/NAPBL00/PreventAD_999145_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s999145.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/999145/NAPBL00/PreventAD_999145_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject 2 /data/preventAD/data/NIAK/ASL_DATA/242152 
files_in.s242152.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/242152/NAPFU03/PreventAD_242152_NAPFU03_ASL001.mnc';   % ASL run 1 
files_in.s242152.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/242152/NAPBL00/PreventAD_242152_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s242152.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/242152/NAPBL00/PreventAD_242152_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject 3 /data/preventAD/data/NIAK/ASL_DATA/534153 
files_in.s534153.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/534153/NAPBL00/PreventAD_534153_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s534153.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/534153/NAPBL00/PreventAD_534153_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject 4 /data/preventAD/data/NIAK/ASL_DATA/465191 
files_in.s465191.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/465191/NAPFU03/PreventAD_465191_NAPFU03_ASL001.mnc';   % ASL run 1 
files_in.s465191.fmri.NAPFU03.asl2                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/465191/NAPFU03/PreventAD_465191_NAPFU03_ASL002.mnc';   % ASL run 2 
files_in.s465191.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/465191/NAPBL00/PreventAD_465191_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s465191.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/465191/NAPBL00/PreventAD_465191_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject 5 /data/preventAD/data/NIAK/ASL_DATA/322960 
files_in.s322960.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/322960/NAPFU03/PreventAD_322960_NAPFU03_ASL001.mnc';   % ASL run 1 
files_in.s322960.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/322960/NAPBL00/PreventAD_322960_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s322960.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/322960/NAPBL00/PreventAD_322960_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject 6 /data/preventAD/data/NIAK/ASL_DATA/621974 
files_in.s621974.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/621974/NAPFU03/PreventAD_621974_NAPFU03_ASL001.mnc';   % ASL run 1 
files_in.s621974.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/621974/NAPBL00/PreventAD_621974_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s621974.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/621974/NAPBL00/PreventAD_621974_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject 7 /data/preventAD/data/NIAK/ASL_DATA/734338 
files_in.s734338.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/734338/NAPFU03/PreventAD_734338_NAPFU03_ASL001.mnc';   % ASL run 1 
files_in.s734338.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/734338/NAPBL00/PreventAD_734338_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s734338.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/734338/NAPBL00/PreventAD_734338_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject 8 /data/preventAD/data/NIAK/ASL_DATA/259716 
files_in.s259716.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/259716/NAPBL00/PreventAD_259716_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s259716.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/259716/NAPBL00/PreventAD_259716_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject 9 /data/preventAD/data/NIAK/ASL_DATA/452408 
files_in.s452408.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/452408/NAPFU03/PreventAD_452408_NAPFU03_ASL001.mnc';   % ASL run 1 
files_in.s452408.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/452408/NAPBL00/PreventAD_452408_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s452408.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/452408/NAPBL00/PreventAD_452408_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject 10 /data/preventAD/data/NIAK/ASL_DATA/624956 
files_in.s624956.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/624956/NAPFU03/PreventAD_624956_NAPFU03_ASL001.mnc';   % ASL run 1 
files_in.s624956.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/624956/NAPBL00/PreventAD_624956_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s624956.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/624956/NAPBL00/PreventAD_624956_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject 11 /data/preventAD/data/NIAK/ASL_DATA/329130 
files_in.s329130.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/329130/NAPBL00/PreventAD_329130_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s329130.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/329130/NAPBL00/PreventAD_329130_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject 12 /data/preventAD/data/NIAK/ASL_DATA/393263 
files_in.s393263.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/393263/NAPBL00/PreventAD_393263_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s393263.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/393263/NAPBL00/PreventAD_393263_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject 13 /data/preventAD/data/NIAK/ASL_DATA/425566 
files_in.s425566.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/425566/NAPBL00/PreventAD_425566_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s425566.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/425566/NAPBL00/PreventAD_425566_NAPBL00_ASL001.mnc';   % ASL run 1 
files_in.s425566.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/425566/NAPFU03/PreventAD_425566_NAPFU03_ASL001.mnc';   % ASL run 1 

 %% Subject 14 /data/preventAD/data/NIAK/ASL_DATA/705569 
files_in.s705569.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/705569/NAPBL00/PreventAD_705569_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s705569.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/705569/NAPBL00/PreventAD_705569_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject 15 /data/preventAD/data/NIAK/ASL_DATA/413587 
files_in.s413587.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/413587/NAPBL00/PreventAD_413587_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s413587.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/413587/NAPBL00/PreventAD_413587_NAPBL00_ASL001.mnc';   % ASL run 1 
files_in.s413587.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/413587/NAPFU03/PreventAD_413587_NAPFU03_ASL001.mnc';   % ASL run 1 

 %% Subject 16 /data/preventAD/data/NIAK/ASL_DATA/839504 
files_in.s839504.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/839504/NAPFU03/PreventAD_839504_NAPFU03_ASL001.mnc';   % ASL run 1 
files_in.s839504.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/839504/NAPBL00/PreventAD_839504_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s839504.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/839504/NAPBL00/PreventAD_839504_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject 17 /data/preventAD/data/NIAK/ASL_DATA/863362 
files_in.s863362.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/863362/NAPFU03/PreventAD_863362_NAPFU03_ASL001.mnc';   % ASL run 1 
files_in.s863362.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/863362/NAPBL00/PreventAD_863362_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s863362.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/863362/NAPBL00/PreventAD_863362_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject 18 /data/preventAD/data/NIAK/ASL_DATA/848487 
files_in.s848487.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/848487/NAPBL00/PreventAD_848487_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s848487.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/848487/NAPBL00/PreventAD_848487_NAPBL00_ASL001.mnc';   % ASL run 1 

%% Subject 19 /data/preventAD/data/NIAK/ASL_DATA/295620 
files_in.s295620.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/295620/NAPBL00/PreventAD_295620_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s295620.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/295620/NAPBL00/PreventAD_295620_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject 20 /data/preventAD/data/NIAK/ASL_DATA/508668 
files_in.s508668.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/508668/PREBL00/PreventAD_508668_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s508668.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/508668/PREBL00/PreventAD_508668_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject 21 /data/preventAD/data/NIAK/ASL_DATA/653279 
files_in.s653279.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/653279/PREBL00/PreventAD_653279_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s653279.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/653279/PREBL00/PreventAD_653279_PREBL00_ASL001.mnc';   % ASL run 1 
files_in.s653279.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/653279/NAPFU03/PreventAD_653279_NAPFU03_ASL001.mnc';   % ASL run 1 

 %% Subject 22 /data/preventAD/data/NIAK/ASL_DATA/250222 
files_in.s250222.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/250222/NAPBL00/PreventAD_250222_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s250222.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/250222/NAPBL00/PreventAD_250222_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject 23 /data/preventAD/data/NIAK/ASL_DATA/295620 
files_in.s295620.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/295620/NAPBL00/PreventAD_295620_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s295620.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/295620/NAPBL00/PreventAD_295620_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject 24 /data/preventAD/data/NIAK/ASL_DATA/306585 
files_in.s306585.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/306585/NAPBL00/PreventAD_306585_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s306585.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/306585/NAPBL00/PreventAD_306585_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject 25 /data/preventAD/data/NIAK/ASL_DATA/322035 
files_in.s322035.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/322035/NAPBL00/PreventAD_322035_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s322035.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/322035/NAPBL00/PreventAD_322035_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject 26 /data/preventAD/data/NIAK/ASL_DATA/396148 
files_in.s396148.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/396148/NAPBL00/PreventAD_396148_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s396148.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/396148/NAPBL00/PreventAD_396148_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject 27 /data/preventAD/data/NIAK/ASL_DATA/503843 
files_in.s503843.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/503843/NAPBL00/PreventAD_503843_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s503843.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/503843/NAPBL00/PreventAD_503843_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject 28 /data/preventAD/data/NIAK/ASL_DATA/749987 
files_in.s749987.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/749987/NAPBL00/PreventAD_749987_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s749987.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/749987/NAPBL00/PreventAD_749987_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject 29 /data/preventAD/data/NIAK/ASL_DATA/758921 
files_in.s758921.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/758921/NAPBL00/PreventAD_758921_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s758921.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/758921/NAPBL00/PreventAD_758921_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject 30 /data/preventAD/data/NIAK/ASL_DATA/966786 
files_in.s966786.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/966786/NAPBL00/PreventAD_966786_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s966786.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/966786/NAPBL00/PreventAD_966786_NAPBL00_ASL001.mnc';   % ASL run 1 


%%%%%%%%%%%%%%%%%%%%%%%
%% Pipeline options  %%
%%%%%%%%%%%%%%%%%%%%%%%

% General
opt.folder_out  = '/sb/project/gsf-624-aa/database/PreventAD/cecile/ASL_out/LP_subset_20130509/';    % Where to store the results
opt.size_output = 'quality_control';                             % The amount of outputs that are generated by the pipeline. 'all' will keep intermediate outputs, 'quality_control' will only keep the quality control outputs. 

% Slice timing correction (niak_brick_slice_timing)
opt.slice_timing.type_acquisition = 'sequential descending'; % Slice timing order (available options : 'sequential ascending', 'sequential descending', 'interleaved ascending', 'interleaved descending')
opt.slice_timing.type_scanner     = 'Siemens';                % Scanner manufacturer. Only the value 'Siemens' will actually have an impact
opt.slice_timing.delay_in_tr      = 0.05;                       % The delay in TR ("blank" time between two volumes)
opt.slice_timing.suppress_vol     = 0;                       % Number of dummy scans to suppress.
opt.slice_timing.flag_skip        = 1;                       % Skip the slice timing (0: don't skip, 1 : skip)

% Motion estimation (niak_pipeline_motion)
opt.motion.session_ref  = 'NAPBL00'; % The session that is used as a reference. In general, use the session including the acqusition of the T1 scan.

% resampling in stereotaxic space
opt.resample_vol.interpolation = 'trilinear'; % The resampling scheme. The most accurate is 'sinc' but it is awfully slow
opt.resample_vol.voxel_size    = [3 3 3];     % The voxel size to use in the stereotaxic space
opt.resample_vol.flag_skip     = 1;           % Skip resampling (data will stay in native functional space after slice timing/motion correction) (0: don't skip, 1 : skip)

% Linear and non-linear fit of the anatomical image in the stereotaxic
% space (niak_brick_t1_preprocess)
opt.t1_preprocess.nu_correct.arg = '-distance 50'; % Parameter for non-uniformity correction. 200 is a suggested value for 1.5T images, 50 for 3T images. If you find that this stage did not work well, this parameter is usually critical to improve the results.

% T1-T2 coregistration (niak_brick_anat2func)
opt.anat2func.init = 'identity'; % An initial guess of the transform. Possible values 'identity', 'center'. 'identity' is self-explanatory. The 'center' option usually does more harm than good. Use it only if you have very big misrealignement between the two images (say, 2 cm).

% Temporal filtering (niak_brick_time_filter)
opt.time_filter.hp = 0.01; % Cut-off frequency for high-pass filtering, or removal of low frequencies (in Hz). A cut-off of -Inf will result in no high-pass filtering.
opt.time_filter.lp = Inf;  % Cut-off frequency for low-pass filtering, or removal of high frequencies (in Hz). A cut-off of Inf will result in no low-pass filtering.

% Regression of confounds and scrubbing (niak_brick_regress_confounds)
opt.regress_confounds.flag_wm = false;            % Turn on/off the regression of the average white matter signal (true: apply / false : don't apply)
opt.regress_confounds.flag_vent = false;          % Turn on/off the regression of the average of the ventricles (true: apply / false : don't apply)
opt.regress_confounds.flag_motion_params = false; % Turn on/off the regression of the motion parameters (true: apply / false : don't apply)
opt.regress_confounds.flag_gsc = false;          % Turn on/off the regression of the PCA-based estimation of the global signal (true: apply / false : don't apply)
opt.regress_confounds.flag_scrubbing = true;     % Turn on/off the scrubbing of time frames with excessive motion (true: apply / false : don't apply)
opt.regress_confounds.thre_fd = 0.5;             % The threshold on frame displacement that is used to determine frames with excessive motion in the scrubbing procedure

% Correction of physiological noise (niak_pipeline_corsica)
opt.corsica.sica.nb_comp             = 60;    % Number of components estimated during the ICA. 20 is a minimal number, 60 was used in the validation of CORSICA.
opt.corsica.threshold                = 0.15;  % This threshold has been calibrated on a validation database as providing good sensitivity with excellent specificity.
opt.corsica.flag_skip                = 1;     % Skip CORSICA (0: don't skip, 1 : skip). Even if it is skipped, ICA results will be generated for quality-control purposes. The method is not currently considered to be stable enough for production unless it is manually supervised.

% Spatial smoothing (niak_brick_smooth_vol)
opt.smooth_vol.fwhm      = 6;  % Full-width at maximum (FWHM) of the Gaussian blurring kernel, in mm.
opt.smooth_vol.flag_skip = 1;  % Skip spatial smoothing (0: don't skip, 1 : skip)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Run the fmri_preprocess pipeline  %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[pipeline,opt] = niak_pipeline_fmri_preprocess(files_in,opt);
