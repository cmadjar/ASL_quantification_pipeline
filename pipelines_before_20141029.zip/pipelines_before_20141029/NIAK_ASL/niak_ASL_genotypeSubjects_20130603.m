% Template to write a script for the NIAK fMRI preprocessing pipeline
%
% To run a demo of the preprocessing, please see
% NIAK_DEMO_FMRI_PREPROCESS.
%
% Copyright (c) Pierre Bellec, 
%   Montreal Neurological Institute, McGill University, 2008-2010.
%   Research Centre of the Montreal Geriatric Institute
%   & Department of Computer Science and Operations Research
%   University of Montreal, Québec, Canada, 2010-2012
% Maintainer : pierre.bellec@criugm.qc.ca
% See licensing information in the code.
% Keywords : medical imaging, fMRI, preprocessing, pipeline

% Permission is hereby granted, free of charge, to any person obtaining a copy
% of this software and associated documentation files (the "Software"), to deal
% in the Software without restriction, including without limitation the rights
% to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
% copies of the Software, and to permit persons to whom the Software is
% furnished to do so, subject to the following conditions:
%
% The above copyright notice and this permission notice shall be included in
% all copies or substantial portions of the Software.
%
% THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
% IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
% FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
% AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
% LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
% OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
% THE SOFTWARE.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Setting input/output files %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% WARNING: Do not use underscores '_' in the IDs of subject, sessions or runs. This may cause bugs in subsequent pipelines.

num_s = 0;

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/125043 
 files_in.s125043vNAPBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/125043/NAPBL00/PreventAD_125043_NAPBL00_adniT1001.mnc';   %Structural scan 
 files_in.s125043vNAPBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/125043/NAPBL00/PreventAD_125043_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/179044 
 files_in.s179044vNAPBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/179044/NAPBL00/PreventAD_179044_NAPBL00_adniT1001.mnc';   %Structural scan 
 files_in.s179044vNAPBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/179044/NAPBL00/PreventAD_179044_NAPBL00_ASL001.mnc';   % ASL run 1 
 %
 files_in.s179044vNAPFU03.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/179044/NAPFU03/PreventAD_179044_NAPFU03_adniT1001.mnc';   %Structural scan 
 files_in.s179044vNAPFU03.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/179044/NAPFU03/PreventAD_179044_NAPFU03_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/213764 
 files_in.s213764vNAPBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/213764/NAPBL00/PreventAD_213764_NAPBL00_adniT1001.mnc';   %Structural scan 
 files_in.s213764vNAPBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/213764/NAPBL00/PreventAD_213764_NAPBL00_ASL001.mnc';   % ASL run 1 
num_s = num_s+1;
opt.tune(num_s).subject = 's213764vNAPBL00';
opt.tune(num_s).param.t1_preprocess.nu_correct.arg = '-distance 25';
 %
 files_in.s213764vNAPFU03.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/213764/NAPFU03/PreventAD_213764_NAPFU03_adniT1001.mnc';   %Structural scan 
 files_in.s213764vNAPFU03.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/213764/NAPFU03/PreventAD_213764_NAPFU03_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/224125 
 files_in.s224125vNAPBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/224125/NAPBL00/PreventAD_224125_NAPBL00_adniT1001.mnc';   %Structural scan 
 files_in.s224125vNAPBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/224125/NAPBL00/PreventAD_224125_NAPBL00_ASL001.mnc';   % ASL run 1 
 %
 files_in.s224125vNAPFU03.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/224125/NAPFU03/PreventAD_224125_NAPFU03_adniT1001.mnc';   %Structural scan 
 files_in.s224125vNAPFU03.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/224125/NAPFU03/PreventAD_224125_NAPFU03_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/263388 
 files_in.s263388vNAPFU03.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/263388/NAPFU03/PreventAD_263388_NAPFU03_adniT1001.mnc';   %Structural scan 
 files_in.s263388vNAPFU03.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/263388/NAPFU03/PreventAD_263388_NAPFU03_ASL001.mnc';   % ASL run 1 
 files_in.s263388vNAPFU03.fmri.session1.asl2                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/263388/NAPFU03/PreventAD_263388_NAPFU03_ASL002.mnc';   % ASL run 2 
 %
 files_in.s263388vNAPBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/263388/NAPBL00/PreventAD_263388_NAPBL00_adniT1001.mnc';   %Structural scan 
 files_in.s263388vNAPBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/263388/NAPBL00/PreventAD_263388_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/266445 
 files_in.s266445vNAPFU03.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/266445/NAPFU03/PreventAD_266445_NAPFU03_adniT1001.mnc';   %Structural scan 
 files_in.s266445vNAPFU03.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/266445/NAPFU03/PreventAD_266445_NAPFU03_ASL001.mnc';   % ASL run 1 
 files_in.s266445vNAPFU03.fmri.session1.asl2                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/266445/NAPFU03/PreventAD_266445_NAPFU03_ASL002.mnc';   % ASL run 2 
 %
 files_in.s266445vNAPBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/266445/NAPBL00/PreventAD_266445_NAPBL00_adniT1001.mnc';   %Structural scan 
 files_in.s266445vNAPBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/266445/NAPBL00/PreventAD_266445_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/267824 
 files_in.s267824vNAPBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/267824/NAPBL00/PreventAD_267824_NAPBL00_adniT1001.mnc';   %Structural scan 
 files_in.s267824vNAPBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/267824/NAPBL00/PreventAD_267824_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/358808 
 files_in.s358808vNAPFU03.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/358808/NAPFU03/PreventAD_358808_NAPFU03_adniT1001.mnc';   %Structural scan 
 files_in.s358808vNAPFU03.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/358808/NAPFU03/PreventAD_358808_NAPFU03_ASL001.mnc';   % ASL run 1 
 files_in.s358808vNAPFU03.fmri.session1.asl2                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/358808/NAPFU03/PreventAD_358808_NAPFU03_ASL002.mnc';   % ASL run 2 
 %
 files_in.s358808vNAPBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/358808/NAPBL00/PreventAD_358808_NAPBL00_adniT1001.mnc';   %Structural scan 
 files_in.s358808vNAPBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/358808/NAPBL00/PreventAD_358808_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/366250 
 files_in.s366250vNAPBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/366250/NAPBL00/PreventAD_366250_NAPBL00_adniT1001.mnc';   %Structural scan 
 files_in.s366250vNAPBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/366250/NAPBL00/PreventAD_366250_NAPBL00_ASL001.mnc';   % ASL run 1 
 %
 files_in.s366250vNAPFU03.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/366250/NAPFU03/PreventAD_366250_NAPFU03_adniT1001.mnc';   %Structural scan 
 files_in.s366250vNAPFU03.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/366250/NAPFU03/PreventAD_366250_NAPFU03_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/367687 
 files_in.s367687vNAPBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/367687/NAPBL00/PreventAD_367687_NAPBL00_adniT1001.mnc';   %Structural scan 
 files_in.s367687vNAPBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/367687/NAPBL00/PreventAD_367687_NAPBL00_ASL001.mnc';   % ASL run 1 
 num_s = num_s+1;
 opt.tune(num_s).subject = 's367687vNAPBL00';
 opt.tune(num_s).param.t1_preprocess.nu_correct.arg = '-distance 15';

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/415554 
 files_in.s415554vNAPBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/415554/NAPBL00/PreventAD_415554_NAPBL00_adniT1001.mnc';   %Structural scan 
 files_in.s415554vNAPBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/415554/NAPBL00/PreventAD_415554_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/415985 
 files_in.s415985vNAPBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/415985/NAPBL00/PreventAD_415985_NAPBL00_adniT1001.mnc';   %Structural scan 
 files_in.s415985vNAPBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/415985/NAPBL00/PreventAD_415985_NAPBL00_ASL001.mnc';   % ASL run 1 
 %
 files_in.s415985vNAPFU03.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/415985/NAPFU03/PreventAD_415985_NAPFU03_adniT1001.mnc';   %Structural scan 
 files_in.s415985vNAPFU03.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/415985/NAPFU03/PreventAD_415985_NAPFU03_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/511467 
 files_in.s511467vNAPBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/511467/NAPBL00/PreventAD_511467_NAPBL00_adniT1001.mnc';   %Structural scan 
 files_in.s511467vNAPBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/511467/NAPBL00/PreventAD_511467_NAPBL00_ASL001.mnc';   % ASL run 1 
 %
 files_in.s511467vNAPFU03.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/511467/NAPFU03/PreventAD_511467_NAPFU03_adniT1001.mnc';   %Structural scan 
 files_in.s511467vNAPFU03.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/511467/NAPFU03/PreventAD_511467_NAPFU03_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/519965 
 files_in.s519965vNAPBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/519965/NAPBL00/PreventAD_519965_NAPBL00_adniT1001.mnc';   %Structural scan 
 files_in.s519965vNAPBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/519965/NAPBL00/PreventAD_519965_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/529692 
 files_in.s529692vNAPBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/529692/NAPBL00/PreventAD_529692_NAPBL00_adniT1001.mnc';   %Structural scan 
 files_in.s529692vNAPBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/529692/NAPBL00/PreventAD_529692_NAPBL00_ASL001.mnc';   % ASL run 1 
num_s = num_s+1;
opt.tune(num_s).subject = 's529692vNAPBL00';
opt.tune(num_s).param.t1_preprocess.nu_correct.arg = '-distance 25';

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/541475 
 files_in.s541475vNAPBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/541475/NAPBL00/PreventAD_541475_NAPBL00_adniT1001.mnc';   %Structural scan 
 files_in.s541475vNAPBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/541475/NAPBL00/PreventAD_541475_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/574029 
 files_in.s574029vNAPBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/574029/NAPBL00/PreventAD_574029_NAPBL00_adniT1002.mnc';   %Structural scan 
 files_in.s574029vNAPBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/574029/NAPBL00/PreventAD_574029_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/605902 
 files_in.s605902vNAPFU03.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/605902/NAPFU03/PreventAD_605902_NAPFU03_adniT1001.mnc';   %Structural scan 
 files_in.s605902vNAPFU03.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/605902/NAPFU03/PreventAD_605902_NAPFU03_ASL001.mnc';   % ASL run 1 
 files_in.s605902vNAPFU03.fmri.session1.asl2                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/605902/NAPFU03/PreventAD_605902_NAPFU03_ASL002.mnc';   % ASL run 2 
 %
 files_in.s605902vNAPBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/605902/NAPBL00/PreventAD_605902_NAPBL00_adniT1001.mnc';   %Structural scan 
 files_in.s605902vNAPBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/605902/NAPBL00/PreventAD_605902_NAPBL00_ASL001.mnc';   % ASL run 1 
 num_s = num_s+1;
 opt.tune(num_s).subject = 's605902vNAPBL00';
 opt.tune(num_s).param.t1_preprocess.nu_correct.arg = '-distance 25';

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/616424 
 files_in.s616424vNAPBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/616424/NAPBL00/PreventAD_616424_NAPBL00_adniT1001.mnc';   %Structural scan 
 files_in.s616424vNAPBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/616424/NAPBL00/PreventAD_616424_NAPBL00_ASL001.mnc';   % ASL run 1 
 %
 files_in.s616424vNAPFU03.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/616424/NAPFU03/PreventAD_616424_NAPFU03_adniT1001.mnc';   %Structural scan 
 files_in.s616424vNAPFU03.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/616424/NAPFU03/PreventAD_616424_NAPFU03_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/633573 
 files_in.s633573vNAPFU03.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/633573/NAPFU03/PreventAD_633573_NAPFU03_adniT1001.mnc';   %Structural scan 
 files_in.s633573vNAPFU03.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/633573/NAPFU03/PreventAD_633573_NAPFU03_ASL001.mnc';   % ASL run 1 
 files_in.s633573vNAPFU03.fmri.session1.asl2                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/633573/NAPFU03/PreventAD_633573_NAPFU03_ASL002.mnc';   % ASL run 2 
 %
 files_in.s633573vNAPBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/633573/NAPBL00/PreventAD_633573_NAPBL00_adniT1001.mnc';   %Structural scan 
 files_in.s633573vNAPBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/633573/NAPBL00/PreventAD_633573_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/642290 
 files_in.s642290vNAPFU03.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/642290/NAPFU03/PreventAD_642290_NAPFU03_adniT1001.mnc';   %Structural scan 
 files_in.s642290vNAPFU03.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/642290/NAPFU03/PreventAD_642290_NAPFU03_ASL001.mnc';   % ASL run 1 
 %
 files_in.s642290vNAPBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/642290/NAPBL00/PreventAD_642290_NAPBL00_adniT1001.mnc';   %Structural scan 
 files_in.s642290vNAPBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/642290/NAPBL00/PreventAD_642290_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/651099 
 files_in.s651099vNAPBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/651099/NAPBL00/PreventAD_651099_NAPBL00_adniT1001.mnc';   %Structural scan 
 files_in.s651099vNAPBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/651099/NAPBL00/PreventAD_651099_NAPBL00_ASL001.mnc';   % ASL run 1 
 %
 files_in.s651099vNAPFU03.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/651099/NAPFU03/PreventAD_651099_NAPFU03_adniT1001.mnc';   %Structural scan 
 files_in.s651099vNAPFU03.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/651099/NAPFU03/PreventAD_651099_NAPFU03_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/672207 
 files_in.s672207vNAPFU03.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/672207/NAPFU03/PreventAD_672207_NAPFU03_adniT1001.mnc';   %Structural scan 
 files_in.s672207vNAPFU03.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/672207/NAPFU03/PreventAD_672207_NAPFU03_ASL001.mnc';   % ASL run 1 
 files_in.s672207vNAPFU03.fmri.session1.asl2                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/672207/NAPFU03/PreventAD_672207_NAPFU03_ASL002.mnc';   % ASL run 2 
 %
 files_in.s672207vNAPBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/672207/NAPBL00/PreventAD_672207_NAPBL00_adniT1001.mnc';   %Structural scan 
 files_in.s672207vNAPBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/672207/NAPBL00/PreventAD_672207_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/685776 
 files_in.s685776vNAPBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/685776/NAPBL00/PreventAD_685776_NAPBL00_adniT1001.mnc';   %Structural scan 
 files_in.s685776vNAPBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/685776/NAPBL00/PreventAD_685776_NAPBL00_ASL001.mnc';   % ASL run 1 


 %% Subject /data/preventAD/data/NIAK/ASL_DATA/742566 
 files_in.s742566vNAPFU03.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/742566/NAPFU03/PreventAD_742566_NAPFU03_adniT1001.mnc';   %Structural scan 
 files_in.s742566vNAPFU03.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/742566/NAPFU03/PreventAD_742566_NAPFU03_ASL001.mnc';   % ASL run 1 
 files_in.s742566vNAPFU03.fmri.session1.asl2                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/742566/NAPFU03/PreventAD_742566_NAPFU03_ASL002.mnc';   % ASL run 2 
 %
 files_in.s742566vNAPBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/742566/NAPBL00/PreventAD_742566_NAPBL00_adniT1001.mnc';   %Structural scan 
 files_in.s742566vNAPBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/742566/NAPBL00/PreventAD_742566_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/746832 
 files_in.s746832vNAPFU03.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/746832/NAPFU03/PreventAD_746832_NAPFU03_adniT1001.mnc';   %Structural scan 
 files_in.s746832vNAPFU03.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/746832/NAPFU03/PreventAD_746832_NAPFU03_ASL001.mnc';   % ASL run 1 
 files_in.s746832vNAPFU03.fmri.session1.asl2                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/746832/NAPFU03/PreventAD_746832_NAPFU03_ASL002.mnc';   % ASL run 2 
 %
 files_in.s746832vNAPBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/746832/NAPBL00/PreventAD_746832_NAPBL00_adniT1001.mnc';   %Structural scan 
 files_in.s746832vNAPBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/746832/NAPBL00/PreventAD_746832_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/748634 
 files_in.s748634vNAPBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/748634/NAPBL00/PreventAD_748634_NAPBL00_adniT1001.mnc';   %Structural scan 
 files_in.s748634vNAPBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/748634/NAPBL00/PreventAD_748634_NAPBL00_ASL001.mnc';   % ASL run 1 
 %
 files_in.s748634vNAPFU03.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/748634/NAPFU03/PreventAD_748634_NAPFU03_adniT1001.mnc';   %Structural scan 
 files_in.s748634vNAPFU03.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/748634/NAPFU03/PreventAD_748634_NAPFU03_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/758274 
 files_in.s758274vNAPBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/758274/NAPBL00/PreventAD_758274_NAPBL00_adniT1001.mnc';   %Structural scan 
 files_in.s758274vNAPBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/758274/NAPBL00/PreventAD_758274_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/807112 
 files_in.s807112vNAPFU03.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/807112/NAPFU03/PreventAD_807112_NAPFU03_adniT1001.mnc';   %Structural scan 
 files_in.s807112vNAPFU03.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/807112/NAPFU03/PreventAD_807112_NAPFU03_ASL001.mnc';   % ASL run 1 
 files_in.s807112vNAPFU03.fmri.session1.asl2                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/807112/NAPFU03/PreventAD_807112_NAPFU03_ASL002.mnc';   % ASL run 2 
 %
 files_in.s807112vNAPBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/807112/NAPBL00/PreventAD_807112_NAPBL00_adniT1001.mnc';   %Structural scan 
 files_in.s807112vNAPBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/807112/NAPBL00/PreventAD_807112_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/818425 
 files_in.s818425vNAPBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/818425/NAPBL00/PreventAD_818425_NAPBL00_adniT1001.mnc';   %Structural scan 
 files_in.s818425vNAPBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/818425/NAPBL00/PreventAD_818425_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/824609 
 files_in.s824609vNAPBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/824609/NAPBL00/PreventAD_824609_NAPBL00_adniT1001.mnc';   %Structural scan 
 files_in.s824609vNAPBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/824609/NAPBL00/PreventAD_824609_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/840092 
 files_in.s840092vNAPBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/840092/NAPBL00/PreventAD_840092_NAPBL00_adniT1001.mnc';   %Structural scan 
 files_in.s840092vNAPBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/840092/NAPBL00/PreventAD_840092_NAPBL00_ASL001.mnc';   % ASL run 1 
 %
 files_in.s840092vNAPFU03.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/840092/NAPFU03/PreventAD_840092_NAPFU03_adniT1001.mnc';   %Structural scan 
 files_in.s840092vNAPFU03.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/840092/NAPFU03/PreventAD_840092_NAPFU03_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/846751 
 files_in.s846751vNAPBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/846751/NAPBL00/PreventAD_846751_NAPBL00_adniT1001.mnc';   %Structural scan 
 files_in.s846751vNAPBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/846751/NAPBL00/PreventAD_846751_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/857385 
 files_in.s857385vNAPBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/857385/NAPBL00/PreventAD_857385_NAPBL00_adniT1001.mnc';   %Structural scan 
 files_in.s857385vNAPBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/857385/NAPBL00/PreventAD_857385_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/939893 
 files_in.s939893vNAPBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/939893/NAPBL00/PreventAD_939893_NAPBL00_adniT1001.mnc';   %Structural scan 
 files_in.s939893vNAPBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/939893/NAPBL00/PreventAD_939893_NAPBL00_ASL001.mnc';   % ASL run 1 
 %
 files_in.s939893vNAPFU03.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/939893/NAPFU03/PreventAD_939893_NAPFU03_adniT1001.mnc';   %Structural scan 
 files_in.s939893vNAPFU03.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/939893/NAPFU03/PreventAD_939893_NAPFU03_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/943843 
 files_in.s943843vNAPBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/943843/NAPBL00/PreventAD_943843_NAPBL00_adniT1001.mnc';   %Structural scan 
 files_in.s943843vNAPBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/943843/NAPBL00/PreventAD_943843_NAPBL00_ASL001.mnc';   % ASL run 1 
 %
 files_in.s943843vNAPFU03.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/943843/NAPFU03/PreventAD_943843_NAPFU03_adniT1001.mnc';   %Structural scan 
 files_in.s943843vNAPFU03.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/943843/NAPFU03/PreventAD_943843_NAPFU03_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/974089 
 files_in.s974089vNAPBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/974089/NAPBL00/PreventAD_974089_NAPBL00_adniT1001.mnc';   %Structural scan 
 files_in.s974089vNAPBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/974089/NAPBL00/PreventAD_974089_NAPBL00_ASL001.mnc';   % ASL run 1 
num_s = num_s+1;
opt.tune(num_s).subject = 's974089vNAPBL00';
opt.tune(num_s).param.t1_preprocess.nu_correct.arg = '-distance 25';

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/996554 
 files_in.s996554vNAPBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/996554/NAPBL00/PreventAD_996554_NAPBL00_adniT1001.mnc';   %Structural scan 
 files_in.s996554vNAPBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/996554/NAPBL00/PreventAD_996554_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/999919 
 files_in.s999919vNAPBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/999919/NAPBL00/PreventAD_999919_NAPBL00_adniT1001.mnc';   %Structural scan 
 files_in.s999919vNAPBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/999919/NAPBL00/PreventAD_999919_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/159332 
files_in.s159332vPREBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/159332/PREBL00/PreventAD_159332_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s159332vPREBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/159332/PREBL00/PreventAD_159332_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/182051 
files_in.s182051vPREBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/182051/PREBL00/PreventAD_182051_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s182051vPREBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/182051/PREBL00/PreventAD_182051_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/195980 
files_in.s195980vPREBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/195980/PREBL00/PreventAD_195980_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s195980vPREBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/195980/PREBL00/PreventAD_195980_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/196834 
files_in.s196834vPREBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/196834/PREBL00/PreventAD_196834_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s196834vPREBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/196834/PREBL00/PreventAD_196834_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/229327 
files_in.s229327vPREBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/229327/PREBL00/PreventAD_229327_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s229327vPREBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/229327/PREBL00/PreventAD_229327_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/259072 
files_in.s259072vPREBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/259072/PREBL00/PreventAD_259072_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s259072vPREBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/259072/PREBL00/PreventAD_259072_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/295195 
files_in.s295195vPREBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/295195/PREBL00/PreventAD_295195_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s295195vPREBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/295195/PREBL00/PreventAD_295195_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/313754 
files_in.s313754vPREBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/313754/PREBL00/PreventAD_313754_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s313754vPREBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/313754/PREBL00/PreventAD_313754_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/336950 
files_in.s336950vPREBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/336950/PREBL00/PreventAD_336950_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s336950vPREBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/336950/PREBL00/PreventAD_336950_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/339400 
files_in.s339400vPREBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/339400/PREBL00/PreventAD_339400_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s339400vPREBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/339400/PREBL00/PreventAD_339400_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/352959 
files_in.s352959vPREBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/352959/PREBL00/PreventAD_352959_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s352959vPREBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/352959/PREBL00/PreventAD_352959_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/376416 
files_in.s376416vPREBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/376416/PREBL00/PreventAD_376416_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s376416vPREBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/376416/PREBL00/PreventAD_376416_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/456836 
files_in.s456836vPREBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/456836/PREBL00/PreventAD_456836_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s456836vPREBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/456836/PREBL00/PreventAD_456836_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/463140 
files_in.s463140vPREBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/463140/PREBL00/PreventAD_463140_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s463140vPREBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/463140/PREBL00/PreventAD_463140_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/510111 
files_in.s510111vPREBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/510111/PREBL00/PreventAD_510111_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s510111vPREBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/510111/PREBL00/PreventAD_510111_PREBL00_ASL001.mnc';   % ASL run 1 
 
 %% Subject /data/preventAD/data/NIAK/ASL_DATA/600099 
files_in.s600099vPREBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/600099/PREBL00/PreventAD_600099_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s600099vPREBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/600099/PREBL00/PreventAD_600099_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/632280 
files_in.s632280vPREBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/632280/PREBL00/PreventAD_632280_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s632280vPREBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/632280/PREBL00/PreventAD_632280_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/668381 
files_in.s668381vPREBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/668381/PREBL00/PreventAD_668381_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s668381vPREBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/668381/PREBL00/PreventAD_668381_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/703846 
files_in.s703846vPREBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/703846/PREBL00/PreventAD_703846_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s703846vPREBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/703846/PREBL00/PreventAD_703846_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/706998 
files_in.s706998vPREBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/706998/PREBL00/PreventAD_706998_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s706998vPREBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/706998/PREBL00/PreventAD_706998_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/713086 
files_in.s713086vPREBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/713086/PREBL00/PreventAD_713086_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s713086vPREBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/713086/PREBL00/PreventAD_713086_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/757121 
files_in.s757121vPREBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/757121/PREBL00/PreventAD_757121_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s757121vPREBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/757121/PREBL00/PreventAD_757121_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/787460 
files_in.s787460vPREBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/787460/PREBL00/PreventAD_787460_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s787460vPREBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/787460/PREBL00/PreventAD_787460_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/832208 
files_in.s832208vPREBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/832208/PREBL00/PreventAD_832208_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s832208vPREBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/832208/PREBL00/PreventAD_832208_PREBL00_ASL001.mnc';   % ASL run 1 
 
 %% Subject /data/preventAD/data/NIAK/ASL_DATA/855307 
files_in.s855307vPREBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/855307/PREBL00/PreventAD_855307_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s855307vPREBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/855307/PREBL00/PreventAD_855307_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/864416 
files_in.s864416vPREBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/864416/PREBL00/PreventAD_864416_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s864416vPREBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/864416/PREBL00/PreventAD_864416_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/910420 
files_in.s910420vPREBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/910420/PREBL00/PreventAD_910420_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s910420vPREBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/910420/PREBL00/PreventAD_910420_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/917380 
files_in.s917380vPREBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/917380/PREBL00/PreventAD_917380_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s917380vPREBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/917380/PREBL00/PreventAD_917380_PREBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/925267 
files_in.s925267vPREBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/925267/PREBL00/PreventAD_925267_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s925267vPREBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/925267/PREBL00/PreventAD_925267_PREBL00_ASL001.mnc';   % ASL run 1 
 
 %% Subject /data/preventAD/data/NIAK/ASL_DATA/827752 %%% Need to reinsert data in DB with right visit label !!!
%files_in.s827752vPREBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/827752/PREBL01/PreventAD_827752_PREBL01_adniT1001.mnc';   %Structural scan 
%files_in.s827752vPREBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/827752/PREBL01/PreventAD_827752_PREBL01_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/719236 
 files_in.s719236vNAPBL00.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/719236/NAPBL00/PreventAD_719236_NAPBL00_adniT1001.mnc';   %Structural scan 
 files_in.s719236vNAPBL00.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/719236/NAPBL00/PreventAD_719236_NAPBL00_ASL001.mnc';   % ASL run 1 
 num_s = num_s+1;
 opt.tune(num_s).subject = 's719236vNAPBL00';
 opt.tune(num_s).param.t1_preprocess.nu_correct.arg = '-distance 20';
 %
 files_in.s719236vNAPFU03.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/719236/NAPFU03/PreventAD_719236_NAPFU03_adniT1001.mnc';   %Structural scan 
 files_in.s719236vNAPFU03.fmri.session1.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/719236/NAPFU03/PreventAD_719236_NAPFU03_ASL001.mnc';   % ASL run 1 


%%%%%%%%%%%%%%%%%%%%%%%
%% Pipeline options  %%
%%%%%%%%%%%%%%%%%%%%%%%

% General
opt.folder_out  = '/sb/project/gsf-624-aa/database/PreventAD/cecile/ASL_out/Genotype_subset_20130603/';    % Where to store the results
opt.size_output = 'quality_control';                             % The amount of outputs that are generated by the pipeline. 'all' will keep intermediate outputs, 'quality_control' will only keep the quality control outputs. 

% Slice timing correction (niak_brick_slice_timing)
opt.slice_timing.type_acquisition = 'sequential descending'; % Slice timing order (available options : 'sequential ascending', 'sequential descending', 'interleaved ascending', 'interleaved descending')
opt.slice_timing.type_scanner     = 'Siemens';                % Scanner manufacturer. Only the value 'Siemens' will actually have an impact
opt.slice_timing.delay_in_tr      = 0.05;                       % The delay in TR ("blank" time between two volumes)
opt.slice_timing.suppress_vol     = 0;                       % Number of dummy scans to suppress.
opt.slice_timing.flag_skip        = 1;                       % Skip the slice timing (0: don't skip, 1 : skip)

% Motion estimation (niak_pipeline_motion)
opt.motion.session_ref  = 'session1'; % The session that is used as a reference. In general, use the session including the acqusition of the T1 scan.

% resampling in stereotaxic space
opt.resample_vol.interpolation = 'trilinear'; % The resampling scheme. The most accurate is 'sinc' but it is awfully slow
opt.resample_vol.voxel_size    = [3 3 3];     % The voxel size to use in the stereotaxic space
opt.resample_vol.flag_skip     = 1;           % Skip resampling (data will stay in native functional space after slice timing/motion correction) (0: don't skip, 1 : skip)

% Linear and non-linear fit of the anatomical image in the stereotaxic
% space (niak_brick_t1_preprocess)
opt.t1_preprocess.nu_correct.arg = '-distance 50'; % Parameter for non-uniformity correction. 200 is a suggested value for 1.5T images, 50 for 3T images. If you find that this stage did not work well, this parameter is usually critical to improve the results.

% T1-T2 coregistration (niak_brick_anat2func)
opt.anat2func.init = 'identity'; % An initial guess of the transform. Possible values 'identity', 'center'. 'identity' is self-explanatory. The 'center' option usually does more harm than good. Use it only if you have very big misrealignement between the two images (say, 2 cm).

% Temporal filtering (niak_brick_time_filter)
opt.time_filter.hp = 0.01; % Cut-off frequency for high-pass filtering, or removal of low frequencies (in Hz). A cut-off of -Inf will result in no high-pass filtering.
opt.time_filter.lp = Inf;  % Cut-off frequency for low-pass filtering, or removal of high frequencies (in Hz). A cut-off of Inf will result in no low-pass filtering.

% Regression of confounds and scrubbing (niak_brick_regress_confounds)
opt.regress_confounds.flag_wm = false;            % Turn on/off the regression of the average white matter signal (true: apply / false : don't apply)
opt.regress_confounds.flag_vent = false;          % Turn on/off the regression of the average of the ventricles (true: apply / false : don't apply)
opt.regress_confounds.flag_motion_params = false; % Turn on/off the regression of the motion parameters (true: apply / false : don't apply)
opt.regress_confounds.flag_gsc = false;          % Turn on/off the regression of the PCA-based estimation of the global signal (true: apply / false : don't apply)
opt.regress_confounds.flag_scrubbing = false;     % Turn on/off the scrubbing of time frames with excessive motion (true: apply / false : don't apply)
opt.regress_confounds.thre_fd = 0.5;             % The threshold on frame displacement that is used to determine frames with excessive motion in the scrubbing procedure

% Correction of physiological noise (niak_pipeline_corsica)
opt.corsica.sica.nb_comp             = 60;    % Number of components estimated during the ICA. 20 is a minimal number, 60 was used in the validation of CORSICA.
opt.corsica.threshold                = 0.15;  % This threshold has been calibrated on a validation database as providing good sensitivity with excellent specificity.
opt.corsica.flag_skip                = 1;     % Skip CORSICA (0: don't skip, 1 : skip). Even if it is skipped, ICA results will be generated for quality-control purposes. The method is not currently considered to be stable enough for production unless it is manually supervised.

% Spatial smoothing (niak_brick_smooth_vol)
opt.smooth_vol.fwhm      = 6;  % Full-width at maximum (FWHM) of the Gaussian blurring kernel, in mm.
opt.smooth_vol.flag_skip = 1;  % Skip spatial smoothing (0: don't skip, 1 : skip)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Run the fmri_preprocess pipeline  %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[pipeline,opt] = niak_pipeline_fmri_preprocess(files_in,opt);
