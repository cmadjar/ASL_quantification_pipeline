% Template to write a script for the NIAK fMRI preprocessing pipeline
%
% To run a demo of the preprocessing, please see
% NIAK_DEMO_FMRI_PREPROCESS.
%
% Copyright (c) Pierre Bellec, 
%   Montreal Neurological Institute, McGill University, 2008-2010.
%   Research Centre of the Montreal Geriatric Institute
%   & Department of Computer Science and Operations Research
%   University of Montreal, Québec, Canada, 2010-2012
% Maintainer : pierre.bellec@criugm.qc.ca
% See licensing information in the code.
% Keywords : medical imaging, fMRI, preprocessing, pipeline

% Permission is hereby granted, free of charge, to any person obtaining a copy
% of this software and associated documentation files (the "Software"), to deal
% in the Software without restriction, including without limitation the rights
% to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
% copies of the Software, and to permit persons to whom the Software is
% furnished to do so, subject to the following conditions:
%
% The above copyright notice and this permission notice shall be included in
% all copies or substantial portions of the Software.
%
% THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
% IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
% FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
% AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
% LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
% OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
% THE SOFTWARE.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Setting input/output files %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% WARNING: Do not use underscores '_' in the IDs of subject, sessions or runs. This may cause bugs in subsequent pipelines.


 %% Subject /data/preventAD/data/NIAK/ASL_DATA/367687 
files_in.s367687.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/367687/NAPBL00/PreventAD_367687_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s367687.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/367687/NAPBL00/PreventAD_367687_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/642290 
files_in.s642290.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/642290/NAPFU03/PreventAD_642290_NAPFU03_ASL001.mnc';   % ASL run 1 
files_in.s642290.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/642290/NAPBL00/PreventAD_642290_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s642290.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/642290/NAPBL00/PreventAD_642290_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/530104 
files_in.s530104.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/530104/NAPBL00/PreventAD_530104_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s530104.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/530104/NAPBL00/PreventAD_530104_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/999145 
files_in.s999145.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/999145/NAPBL00/PreventAD_999145_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s999145.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/999145/NAPBL00/PreventAD_999145_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/242152 
files_in.s242152.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/242152/NAPFU03/PreventAD_242152_NAPFU03_ASL001.mnc';   % ASL run 1 
files_in.s242152.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/242152/NAPBL00/PreventAD_242152_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s242152.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/242152/NAPBL00/PreventAD_242152_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/534153 
files_in.s534153.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/534153/NAPBL00/PreventAD_534153_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s534153.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/534153/NAPBL00/PreventAD_534153_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/807112 
files_in.s807112.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/807112/NAPFU03/PreventAD_807112_NAPFU03_ASL001.mnc';   % ASL run 1 
files_in.s807112.fmri.NAPFU03.asl2                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/807112/NAPFU03/PreventAD_807112_NAPFU03_ASL002.mnc';   % ASL run 2 
files_in.s807112.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/807112/NAPBL00/PreventAD_807112_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s807112.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/807112/NAPBL00/PreventAD_807112_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/465191 
files_in.s465191.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/465191/NAPFU03/PreventAD_465191_NAPFU03_ASL001.mnc';   % ASL run 1 
files_in.s465191.fmri.NAPFU03.asl2                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/465191/NAPFU03/PreventAD_465191_NAPFU03_ASL002.mnc';   % ASL run 2 
files_in.s465191.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/465191/NAPBL00/PreventAD_465191_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s465191.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/465191/NAPBL00/PreventAD_465191_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/749987 
files_in.s749987.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/749987/NAPBL00/PreventAD_749987_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s749987.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/749987/NAPBL00/PreventAD_749987_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/322960 
files_in.s322960.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/322960/NAPFU03/PreventAD_322960_NAPFU03_ASL001.mnc';   % ASL run 1 
files_in.s322960.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/322960/NAPBL00/PreventAD_322960_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s322960.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/322960/NAPBL00/PreventAD_322960_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/415554 
files_in.s415554.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/415554/NAPBL00/PreventAD_415554_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s415554.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/415554/NAPBL00/PreventAD_415554_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/746832 
files_in.s746832.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/746832/NAPFU03/PreventAD_746832_NAPFU03_ASL001.mnc';   % ASL run 1 
files_in.s746832.fmri.NAPFU03.asl2                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/746832/NAPFU03/PreventAD_746832_NAPFU03_ASL002.mnc';   % ASL run 2 
files_in.s746832.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/746832/NAPBL00/PreventAD_746832_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s746832.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/746832/NAPBL00/PreventAD_746832_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/742566 
files_in.s742566.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/742566/NAPFU03/PreventAD_742566_NAPFU03_ASL001.mnc';   % ASL run 1 
files_in.s742566.fmri.NAPFU03.asl2                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/742566/NAPFU03/PreventAD_742566_NAPFU03_ASL002.mnc';   % ASL run 2 
files_in.s742566.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/742566/NAPBL00/PreventAD_742566_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s742566.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/742566/NAPBL00/PreventAD_742566_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/621974 
files_in.s621974.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/621974/NAPFU03/PreventAD_621974_NAPFU03_ASL001.mnc';   % ASL run 1 
files_in.s621974.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/621974/NAPBL00/PreventAD_621974_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s621974.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/621974/NAPBL00/PreventAD_621974_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/511467 
files_in.s511467.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/511467/NAPBL00/PreventAD_511467_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s511467.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/511467/NAPBL00/PreventAD_511467_NAPBL00_ASL001.mnc';   % ASL run 1 
files_in.s511467.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/511467/NAPFU03/PreventAD_511467_NAPFU03_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/358808 
files_in.s358808.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/358808/NAPFU03/PreventAD_358808_NAPFU03_ASL001.mnc';   % ASL run 1 
files_in.s358808.fmri.NAPFU03.asl2                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/358808/NAPFU03/PreventAD_358808_NAPFU03_ASL002.mnc';   % ASL run 2 
files_in.s358808.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/358808/NAPBL00/PreventAD_358808_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s358808.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/358808/NAPBL00/PreventAD_358808_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/366250 
files_in.s366250.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/366250/NAPBL00/PreventAD_366250_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s366250.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/366250/NAPBL00/PreventAD_366250_NAPBL00_ASL001.mnc';   % ASL run 1 
files_in.s366250.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/366250/NAPFU03/PreventAD_366250_NAPFU03_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/848487 
files_in.s848487.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/848487/NAPBL00/PreventAD_848487_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s848487.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/848487/NAPBL00/PreventAD_848487_NAPBL00_ASL001.mnc';   % ASL run 1 
files_in.s848487.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/848487/NAPFU03/PreventAD_848487_NAPFU03_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/605902 
files_in.s605902.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/605902/NAPFU03/PreventAD_605902_NAPFU03_ASL001.mnc';   % ASL run 1 
files_in.s605902.fmri.NAPFU03.asl2                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/605902/NAPFU03/PreventAD_605902_NAPFU03_ASL002.mnc';   % ASL run 2 
files_in.s605902.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/605902/NAPBL00/PreventAD_605902_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s605902.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/605902/NAPBL00/PreventAD_605902_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/943843 
files_in.s943843.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/943843/NAPBL00/PreventAD_943843_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s943843.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/943843/NAPBL00/PreventAD_943843_NAPBL00_ASL001.mnc';   % ASL run 1 
files_in.s943843.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/943843/NAPFU03/PreventAD_943843_NAPFU03_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/734338 
files_in.s734338.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/734338/NAPFU03/PreventAD_734338_NAPFU03_ASL001.mnc';   % ASL run 1 
files_in.s734338.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/734338/NAPBL00/PreventAD_734338_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s734338.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/734338/NAPBL00/PreventAD_734338_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/748634 
files_in.s748634.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/748634/NAPBL00/PreventAD_748634_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s748634.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/748634/NAPBL00/PreventAD_748634_NAPBL00_ASL001.mnc';   % ASL run 1 
files_in.s748634.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/748634/NAPFU03/PreventAD_748634_NAPFU03_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/259716 
files_in.s259716.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/259716/NAPBL00/PreventAD_259716_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s259716.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/259716/NAPBL00/PreventAD_259716_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/224125 
files_in.s224125.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/224125/NAPBL00/PreventAD_224125_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s224125.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/224125/NAPBL00/PreventAD_224125_NAPBL00_ASL001.mnc';   % ASL run 1 
files_in.s224125.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/224125/NAPFU03/PreventAD_224125_NAPFU03_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/719236 
files_in.s719236.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/719236/NAPBL00/PreventAD_719236_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s719236.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/719236/NAPBL00/PreventAD_719236_NAPBL00_ASL001.mnc';   % ASL run 1 
files_in.s719236.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/719236/NAPFU03/PreventAD_719236_NAPFU03_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/616424 
files_in.s616424.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/616424/NAPBL00/PreventAD_616424_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s616424.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/616424/NAPBL00/PreventAD_616424_NAPBL00_ASL001.mnc';   % ASL run 1 
files_in.s616424.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/616424/NAPFU03/PreventAD_616424_NAPFU03_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/415985 
files_in.s415985.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/415985/NAPBL00/PreventAD_415985_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s415985.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/415985/NAPBL00/PreventAD_415985_NAPBL00_ASL001.mnc';   % ASL run 1 
files_in.s415985.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/415985/NAPFU03/PreventAD_415985_NAPFU03_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/452408 
files_in.s452408.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/452408/NAPFU03/PreventAD_452408_NAPFU03_ASL001.mnc';   % ASL run 1 
files_in.s452408.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/452408/NAPBL00/PreventAD_452408_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s452408.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/452408/NAPBL00/PreventAD_452408_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/824609 
files_in.s824609.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/824609/NAPBL00/PreventAD_824609_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s824609.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/824609/NAPBL00/PreventAD_824609_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/624956 
files_in.s624956.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/624956/NAPFU03/PreventAD_624956_NAPFU03_ASL001.mnc';   % ASL run 1 
files_in.s624956.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/624956/NAPBL00/PreventAD_624956_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s624956.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/624956/NAPBL00/PreventAD_624956_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/329130 
files_in.s329130.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/329130/NAPBL00/PreventAD_329130_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s329130.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/329130/NAPBL00/PreventAD_329130_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/156450 
files_in.s156450.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/156450/NAPBL00/PreventAD_156450_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s156450.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/156450/NAPBL00/PreventAD_156450_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/393263 
files_in.s393263.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/393263/NAPBL00/PreventAD_393263_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s393263.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/393263/NAPBL00/PreventAD_393263_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/857385 
files_in.s857385.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/857385/NAPBL00/PreventAD_857385_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s857385.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/857385/NAPBL00/PreventAD_857385_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/213764 
files_in.s213764.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/213764/NAPBL00/PreventAD_213764_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s213764.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/213764/NAPBL00/PreventAD_213764_NAPBL00_ASL001.mnc';   % ASL run 1 
files_in.s213764.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/213764/NAPFU03/PreventAD_213764_NAPFU03_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/840092 
files_in.s840092.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/840092/NAPBL00/PreventAD_840092_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s840092.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/840092/NAPBL00/PreventAD_840092_NAPBL00_ASL001.mnc';   % ASL run 1 
files_in.s840092.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/840092/NAPFU03/PreventAD_840092_NAPFU03_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/651099 
files_in.s651099.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/651099/NAPBL00/PreventAD_651099_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s651099.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/651099/NAPBL00/PreventAD_651099_NAPBL00_ASL001.mnc';   % ASL run 1 
files_in.s651099.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/651099/NAPFU03/PreventAD_651099_NAPFU03_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/762800 
files_in.s762800.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/762800/NAPBL00/PreventAD_762800_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s762800.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/762800/NAPBL00/PreventAD_762800_NAPBL00_ASL001.mnc';   % ASL run 1 
files_in.s762800.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/762800/NAPFU03/PreventAD_762800_NAPFU03_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/425566 
files_in.s425566.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/425566/NAPBL00/PreventAD_425566_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s425566.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/425566/NAPBL00/PreventAD_425566_NAPBL00_ASL001.mnc';   % ASL run 1 
files_in.s425566.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/425566/NAPFU03/PreventAD_425566_NAPFU03_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/529692 
files_in.s529692.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/529692/NAPBL00/PreventAD_529692_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s529692.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/529692/NAPBL00/PreventAD_529692_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/705569 
files_in.s705569.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/705569/NAPBL00/PreventAD_705569_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s705569.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/705569/NAPBL00/PreventAD_705569_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/306585 
files_in.s306585.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/306585/NAPBL00/PreventAD_306585_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s306585.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/306585/NAPBL00/PreventAD_306585_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/413587 
files_in.s413587.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/413587/NAPBL00/PreventAD_413587_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s413587.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/413587/NAPBL00/PreventAD_413587_NAPBL00_ASL001.mnc';   % ASL run 1 
files_in.s413587.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/413587/NAPFU03/PreventAD_413587_NAPFU03_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/413786 
files_in.s413786.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/413786/NAPFU03/PreventAD_413786_NAPFU03_ASL001.mnc';   % ASL run 1 
files_in.s413786.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/413786/NAPBL00/PreventAD_413786_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s413786.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/413786/NAPBL00/PreventAD_413786_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/179044 
files_in.s179044.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/179044/NAPBL00/PreventAD_179044_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s179044.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/179044/NAPBL00/PreventAD_179044_NAPBL00_ASL001.mnc';   % ASL run 1 
files_in.s179044.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/179044/NAPFU03/PreventAD_179044_NAPFU03_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/672207 
files_in.s672207.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/672207/NAPFU03/PreventAD_672207_NAPFU03_ASL001.mnc';   % ASL run 1 
files_in.s672207.fmri.NAPFU03.asl2                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/672207/NAPFU03/PreventAD_672207_NAPFU03_ASL002.mnc';   % ASL run 2 
files_in.s672207.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/672207/NAPBL00/PreventAD_672207_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s672207.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/672207/NAPBL00/PreventAD_672207_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/267824 
files_in.s267824.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/267824/NAPBL00/PreventAD_267824_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s267824.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/267824/NAPBL00/PreventAD_267824_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/846751 
files_in.s846751.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/846751/NAPBL00/PreventAD_846751_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s846751.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/846751/NAPBL00/PreventAD_846751_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/263388 
files_in.s263388.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/263388/NAPFU03/PreventAD_263388_NAPFU03_ASL001.mnc';   % ASL run 1 
files_in.s263388.fmri.NAPFU03.asl2                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/263388/NAPFU03/PreventAD_263388_NAPFU03_ASL002.mnc';   % ASL run 2 
files_in.s263388.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/263388/NAPBL00/PreventAD_263388_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s263388.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/263388/NAPBL00/PreventAD_263388_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/882120 
files_in.s882120.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/882120/NAPBL00/PreventAD_882120_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s882120.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/882120/NAPBL00/PreventAD_882120_NAPBL00_ASL001.mnc';   % ASL run 1 
files_in.s882120.fmri.NAPBL00.asl2                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/882120/NAPBL00/PreventAD_882120_NAPBL00_ASL002.mnc';   % ASL run 2 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/541475 
files_in.s541475.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/541475/NAPBL00/PreventAD_541475_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s541475.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/541475/NAPBL00/PreventAD_541475_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/839504 
files_in.s839504.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/839504/NAPFU03/PreventAD_839504_NAPFU03_ASL001.mnc';   % ASL run 1 
files_in.s839504.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/839504/NAPBL00/PreventAD_839504_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s839504.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/839504/NAPBL00/PreventAD_839504_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/966786 
files_in.s966786.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/966786/NAPBL00/PreventAD_966786_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s966786.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/966786/NAPBL00/PreventAD_966786_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/727207 
files_in.s727207.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/727207/NAPBL00/PreventAD_727207_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s727207.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/727207/NAPBL00/PreventAD_727207_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/535893 
files_in.s535893.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/535893/NAPBL00/PreventAD_535893_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s535893.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/535893/NAPBL00/PreventAD_535893_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/939893 
files_in.s939893.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/939893/NAPBL00/PreventAD_939893_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s939893.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/939893/NAPBL00/PreventAD_939893_NAPBL00_ASL001.mnc';   % ASL run 1 
files_in.s939893.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/939893/NAPFU03/PreventAD_939893_NAPFU03_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/633573 
files_in.s633573.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/633573/NAPFU03/PreventAD_633573_NAPFU03_ASL001.mnc';   % ASL run 1 
files_in.s633573.fmri.NAPFU03.asl2                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/633573/NAPFU03/PreventAD_633573_NAPFU03_ASL002.mnc';   % ASL run 2 
files_in.s633573.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/633573/NAPBL00/PreventAD_633573_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s633573.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/633573/NAPBL00/PreventAD_633573_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/758274 
files_in.s758274.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/758274/NAPBL00/PreventAD_758274_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s758274.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/758274/NAPBL00/PreventAD_758274_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/863362 
files_in.s863362.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/863362/NAPFU03/PreventAD_863362_NAPFU03_ASL001.mnc';   % ASL run 1 
files_in.s863362.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/863362/NAPBL00/PreventAD_863362_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s863362.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/863362/NAPBL00/PreventAD_863362_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/758921 
files_in.s758921.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/758921/NAPBL00/PreventAD_758921_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s758921.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/758921/NAPBL00/PreventAD_758921_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/266445 
files_in.s266445.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/266445/NAPFU03/PreventAD_266445_NAPFU03_ASL001.mnc';   % ASL run 1 
files_in.s266445.fmri.NAPFU03.asl2                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/266445/NAPFU03/PreventAD_266445_NAPFU03_ASL002.mnc';   % ASL run 2 
files_in.s266445.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/266445/NAPBL00/PreventAD_266445_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s266445.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/266445/NAPBL00/PreventAD_266445_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/125043 
files_in.s125043.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/125043/NAPBL00/PreventAD_125043_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s125043.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/125043/NAPBL00/PreventAD_125043_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/519965 
files_in.s519965.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/519965/NAPBL00/PreventAD_519965_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s519965.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/519965/NAPBL00/PreventAD_519965_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/685776 
files_in.s685776.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/685776/NAPBL00/PreventAD_685776_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s685776.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/685776/NAPBL00/PreventAD_685776_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/818425 
files_in.s818425.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/818425/NAPBL00/PreventAD_818425_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s818425.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/818425/NAPBL00/PreventAD_818425_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/250222 
files_in.s250222.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/250222/NAPBL00/PreventAD_250222_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s250222.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/250222/NAPBL00/PreventAD_250222_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/396148 
files_in.s396148.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/396148/NAPBL00/PreventAD_396148_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s396148.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/396148/NAPBL00/PreventAD_396148_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/999919 
files_in.s999919.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/999919/NAPBL00/PreventAD_999919_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s999919.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/999919/NAPBL00/PreventAD_999919_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/503843 
files_in.s503843.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/503843/NAPBL00/PreventAD_503843_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s503843.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/503843/NAPBL00/PreventAD_503843_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/574029 
files_in.s574029.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/574029/NAPBL00/PreventAD_574029_NAPBL00_adniT1002.mnc';   %Structural scan 
files_in.s574029.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/574029/NAPBL00/PreventAD_574029_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/974089 
files_in.s974089.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/974089/NAPBL00/PreventAD_974089_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s974089.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/974089/NAPBL00/PreventAD_974089_NAPBL00_ASL001.mnc';   % ASL run 1 

%% Subject /data/preventAD/data/NIAK/ASL_DATA/295620 
files_in.s295620.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/295620/NAPBL00/PreventAD_295620_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s295620.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/295620/NAPBL00/PreventAD_295620_NAPBL00_ASL001.mnc';   % ASL run 1 

%% Subject /data/preventAD/data/NIAK/ASL_DATA/322035 
files_in.s322035.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/322035/NAPBL00/PreventAD_322035_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s322035.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/322035/NAPBL00/PreventAD_322035_NAPBL00_ASL001.mnc';   % ASL run 1 

%% Subject /data/preventAD/data/NIAK/ASL_DATA/518271 
files_in.s518271.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/518271/NAPBL00/PreventAD_518271_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s518271.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/518271/NAPBL00/PreventAD_518271_NAPBL00_ASL001.mnc';   % ASL run 1 

%% Subject /data/preventAD/data/NIAK/ASL_DATA/871075 
files_in.s871075.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/871075/NAPBL00/PreventAD_871075_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s871075.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/871075/NAPBL00/PreventAD_871075_NAPBL00_ASL001.mnc';   % ASL run 1 

%% Subject /data/preventAD/data/NIAK/ASL_DATA/996554 
files_in.s996554.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/996554/NAPBL00/PreventAD_996554_NAPBL00_adniT1001.mnc';   %Structural scan 
files_in.s996554.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/996554/NAPBL00/PreventAD_996554_NAPBL00_ASL001.mnc';   % ASL run 1 

 %% Subject /data/preventAD/data/NIAK/ASL_DATA/653279 
files_in.s653279.anat                  = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/653279/PREBL00/PreventAD_653279_PREBL00_adniT1001.mnc';   %Structural scan 
files_in.s653279.fmri.NAPBL00.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/653279/PREBL00/PreventAD_653279_PREBL00_ASL001.mnc';   % ASL run 1 
files_in.s653279.fmri.NAPFU03.asl1                = '/home/cmadjar/database/PreventAD/cecile/ASL_raw/DATA/653279/NAPFU03/PreventAD_653279_NAPFU03_ASL001.mnc';   % ASL run 1 



%%%%%%%%%%%%%%%%%%%%%%%
%% Pipeline options  %%
%%%%%%%%%%%%%%%%%%%%%%%

% General
opt.folder_out  = '/sb/project/gsf-624-aa/database/PreventAD/cecile/ASL_out/NAP/';    % Where to store the results
opt.size_output = 'quality_control';                             % The amount of outputs that are generated by the pipeline. 'all' will keep intermediate outputs, 'quality_control' will only keep the quality control outputs. 

% Slice timing correction (niak_brick_slice_timing)
opt.slice_timing.type_acquisition = 'sequential descending'; % Slice timing order (available options : 'sequential ascending', 'sequential descending', 'interleaved ascending', 'interleaved descending')
opt.slice_timing.type_scanner     = 'Siemens';                % Scanner manufacturer. Only the value 'Siemens' will actually have an impact
opt.slice_timing.delay_in_tr      = 0.05;                       % The delay in TR ("blank" time between two volumes)
opt.slice_timing.suppress_vol     = 0;                       % Number of dummy scans to suppress.
opt.slice_timing.flag_skip        = 1;                       % Skip the slice timing (0: don't skip, 1 : skip)

% Motion estimation (niak_pipeline_motion)
opt.motion.session_ref  = 'NAPBL00'; % The session that is used as a reference. In general, use the session including the acqusition of the T1 scan.

% resampling in stereotaxic space
opt.resample_vol.interpolation = 'trilinear'; % The resampling scheme. The most accurate is 'sinc' but it is awfully slow
opt.resample_vol.voxel_size    = [3 3 3];     % The voxel size to use in the stereotaxic space
opt.resample_vol.flag_skip     = 1;           % Skip resampling (data will stay in native functional space after slice timing/motion correction) (0: don't skip, 1 : skip)

% Linear and non-linear fit of the anatomical image in the stereotaxic
% space (niak_brick_t1_preprocess)
opt.t1_preprocess.nu_correct.arg = '-distance 50'; % Parameter for non-uniformity correction. 200 is a suggested value for 1.5T images, 50 for 3T images. If you find that this stage did not work well, this parameter is usually critical to improve the results.

% T1-T2 coregistration (niak_brick_anat2func)
opt.anat2func.init = 'identity'; % An initial guess of the transform. Possible values 'identity', 'center'. 'identity' is self-explanatory. The 'center' option usually does more harm than good. Use it only if you have very big misrealignement between the two images (say, 2 cm).

% Temporal filtering (niak_brick_time_filter)
opt.time_filter.hp = 0.01; % Cut-off frequency for high-pass filtering, or removal of low frequencies (in Hz). A cut-off of -Inf will result in no high-pass filtering.
opt.time_filter.lp = Inf;  % Cut-off frequency for low-pass filtering, or removal of high frequencies (in Hz). A cut-off of Inf will result in no low-pass filtering.

% Regression of confounds and scrubbing (niak_brick_regress_confounds)
opt.regress_confounds.flag_wm = false;            % Turn on/off the regression of the average white matter signal (true: apply / false : don't apply)
opt.regress_confounds.flag_vent = false;          % Turn on/off the regression of the average of the ventricles (true: apply / false : don't apply)
opt.regress_confounds.flag_motion_params = false; % Turn on/off the regression of the motion parameters (true: apply / false : don't apply)
opt.regress_confounds.flag_gsc = false;          % Turn on/off the regression of the PCA-based estimation of the global signal (true: apply / false : don't apply)
opt.regress_confounds.flag_scrubbing = true;     % Turn on/off the scrubbing of time frames with excessive motion (true: apply / false : don't apply)
opt.regress_confounds.thre_fd = 0.5;             % The threshold on frame displacement that is used to determine frames with excessive motion in the scrubbing procedure

% Correction of physiological noise (niak_pipeline_corsica)
opt.corsica.sica.nb_comp             = 60;    % Number of components estimated during the ICA. 20 is a minimal number, 60 was used in the validation of CORSICA.
opt.corsica.threshold                = 0.15;  % This threshold has been calibrated on a validation database as providing good sensitivity with excellent specificity.
opt.corsica.flag_skip                = 1;     % Skip CORSICA (0: don't skip, 1 : skip). Even if it is skipped, ICA results will be generated for quality-control purposes. The method is not currently considered to be stable enough for production unless it is manually supervised.

% Spatial smoothing (niak_brick_smooth_vol)
opt.smooth_vol.fwhm      = 6;  % Full-width at maximum (FWHM) of the Gaussian blurring kernel, in mm.
opt.smooth_vol.flag_skip = 1;  % Skip spatial smoothing (0: don't skip, 1 : skip)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Run the fmri_preprocess pipeline  %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[pipeline,opt] = niak_pipeline_fmri_preprocess(files_in,opt);
